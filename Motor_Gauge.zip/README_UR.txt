Motor Formula Android APK بنانے کا طریقہ

یہ Android Studio/Gradle پروجیکٹ ہے؛ APK خود اس پیکج کے اندر پہلے سے compile نہیں ہوئی۔

اگر GitHub استعمال کرنا ہے:
1) اس ZIP کو extract کریں۔
2) اس کے اندر موجود تمام فائلیں اپنے GitHub repository کی root میں upload کریں (README_UR.txt سمیت)۔
3) GitHub میں repository > Actions کھولیں۔
4) 'Build Motor Formula APK' workflow چلائیں یا main branch پر فائلیں push ہونے دیں۔
5) workflow مکمل ہونے پر run کھولیں، Artifacts میں 'Motor-Formula-APK' ڈاؤن لوڈ کریں۔
6) ZIP artifact کھولیں؛ app-debug.apk موبائل پر بھیج کر انسٹال کریں۔ Android شاید unknown apps کی اجازت مانگے۔
نوٹ: یہ debug APK ہے، Play Store والی signed release نہیں۔
ایپ کے ریکارڈ فون کے اندر مقامی طور پر محفوظ ہوتے ہیں۔ فون/ایپ کا ڈیٹا صاف کرنے سے پہلے ایپ کے اندر بیک اپ بنائیں۔

App label: Motor Formula
In-app shop heading: \u0639\u0644\u06cc \u0627\u0644\u06cc\u06a9\u0679\u0631\u06a9 \u0627\u0633\u0679\u0648\u0631
